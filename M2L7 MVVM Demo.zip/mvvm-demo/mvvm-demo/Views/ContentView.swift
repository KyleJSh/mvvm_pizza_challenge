//
//  ContentView.swift
//  mvvm-demo
//
//  Created by Christopher Ching on 2021-01-07.
//

import SwiftUI

struct ContentView: View {
    
    var model = RecipeModel()
    
    var body: some View {
        
        List(model.recipes) { r in
            
            VStack(alignment: .leading) {
                Text(r.name)
                    .font(.title)
                Text(r.cuisine)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
