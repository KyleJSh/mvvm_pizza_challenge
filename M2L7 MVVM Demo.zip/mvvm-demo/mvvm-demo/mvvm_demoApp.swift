//
//  mvvm_demoApp.swift
//  mvvm-demo
//
//  Created by Christopher Ching on 2021-01-07.
//

import SwiftUI

@main
struct mvvm_demoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
