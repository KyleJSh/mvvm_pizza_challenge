//
//  RecipeModel.swift
//  mvvm-demo
//
//  Created by Christopher Ching on 2021-01-07.
//

import Foundation

class RecipeModel {
    
    var recipes = [Recipe]()
    
    init() {
        
        // Create some dummy recipe data
        recipes.append(Recipe(name: "Spaghetti", cuisine: "Italian"))
        
        recipes.append(Recipe(name: "Sushi", cuisine: "Japanese"))
    }
}
